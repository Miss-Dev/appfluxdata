import flet as ft
from time import sleep

import datetime
from utils.ble_utils import busca_dispositivos, conecta_dispositivo, recebe_dados
from utils.funcoes_uteis import escreve_cabecalho, gera_grafico


def main(pagina: ft.Page):
    pagina.title = "App Data Fluxo"

    pagina.horizontal_alignment = "center"
    global lista
    socket = None
    lista = []
    titulo = ft.Text("AppDataFluxo: \nGere arquivos csv e gráficos com a leitura dos dados.", weight="bold",
                     color="#2F4F4F", text_align="center")
    img_icon = ft.Image(
        src="imgs/analytics-3268935_640.jpg",
        width=200
    )
    pagina.add(img_icon)
    c1 = ft.Container(
        content=titulo,
        width=600
    )

    pagina.add(c1)

    pagina.add(ft.Text("Conectar bluetooth:"))

    def buscar_dispositivo(e):

        pb = ft.ProgressBar(width=400)
        texto = ft.Text("Buscando dispositivos", style="headlineSmall")
        barra_progresso = ft.Column([ft.Text("Aguarde..."), pb])

        pagina.add(
            texto,
            barra_progresso
        )

        lista = busca_dispositivos()

        for i in range(0, 101):
            pb.value = i * 0.01
            sleep(0.08)
            pagina.update()

        if len(lista) == 0:
            t.value = "Verifique a conexão bluetooth, nenhum dispositivo localizado."
            pagina.remove(texto, barra_progresso)
        else:
            pagina.remove(texto, barra_progresso)

            def button_clicked(e):
                output_text.value = f"Dispositivo selecionado:  {color_dropdown.value}"
                sleep(0.1)
                dispositivo_selecionado = str(color_dropdown.value)
                if dispositivo_selecionado is not None and dispositivo_selecionado != "":
                    socket = conecta_dispositivo(dispositivo_selecionado.split("-")[1].strip())

                    if socket is not None:
                        timestamp = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
                        caminho_arquivo = f'dados_{timestamp}.csv'
                        escreve_cabecalho(caminho_arquivo)

                        def botao_parar(e):
                            parar_leitura.data = True
                            output_text.value = "Arquivo csv gerado com sucesso..."
                            pagina.update()

                        parar_leitura = ft.ElevatedButton(text="Parar", on_click=botao_parar, data=False)
                        pagina.add(parar_leitura)

                        controle = True
                        while not parar_leitura.data:
                            output_text.value = "Recebendo dados do dispositivo..."

                            dados = recebe_dados(socket)
                            if controle:
                                graf_img = ft.Image(
                                    src=gera_grafico(dados.replace("\r\n", "")),
                                    width=400
                                )
                                pagina.add(graf_img)
                                controle = False
                            with open(caminho_arquivo, 'a') as arquivo_csv:
                                arquivo_csv.write(dados.replace("\r\n", "") + '\n')
                        pagina.update()

                pagina.update()

            pagina.add(ft.Text("Selecione o dispositivo:"))
            output_text = ft.Text()

            submit_btn = ft.ElevatedButton(text="Iniciar", on_click=button_clicked)

            color_dropdown = ft.Dropdown(
                height=30,
                width=300,
                text_size=15,
                options=[ft.dropdown.Option(disp) for disp in lista],
            )
            pagina.add(color_dropdown, submit_btn, output_text)

    b = ft.IconButton(
        icon=ft.icons.BLUETOOTH_CONNECTED, on_click=buscar_dispositivo, data=0, icon_size=40
    )
    t = ft.Text()

    pagina.add(b, t)
    sleep(2)


ft.app(target=main, view=ft.AppView.WEB_BROWSER, web_renderer=ft.WebRenderer.HTML)