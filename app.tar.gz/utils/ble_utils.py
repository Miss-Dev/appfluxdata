import bluetooth


def busca_dispositivos():
    dispositivos = bluetooth.discover_devices()
    return pega_dados_dispositivos(dispositivos)


def pega_dados_dispositivos(dispositivos: list):
    lista_dados = []
    for endereco_mac in dispositivos:
        try:
            # Obtém o nome do dispositivo usando o endereço MAC
            nome_dispositivo = bluetooth.lookup_name(endereco_mac)
            if nome_dispositivo is None:
                nome_dispositivo = "Dispositivo desconhecido"
            lista_dados.append(nome_dispositivo + " - " + endereco_mac)
            print("Endereço MAC:", endereco_mac)
            print("Nome do Dispositivo:", nome_dispositivo)
        except Exception as e:
            print("Erro ao obter nome do dispositivo:", e)
    return lista_dados

def conecta_dispositivo(end_mac: str):
    porta = 1

    sock = bluetooth.BluetoothSocket(bluetooth.RFCOMM)
    try:
        sock.connect((end_mac, porta))

    except bluetooth.btcommon.BluetoothError as e:
        print('Erro de conexão:', e)
        return None

    return sock


def recebe_dados(socket, buffer_size=1024):
    data = socket.recv(buffer_size)
    if data:
        return data.decode()
