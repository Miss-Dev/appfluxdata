import pandas as pd
import matplotlib.pyplot as plt
from io import BytesIO
import base64
import tempfile


def escreve_cabecalho(caminho_arquivo):
    with open(caminho_arquivo, 'w') as arquivo_csv:
        arquivo_csv.write(
            "Tempo(ms), Fluxo Raw, Fluxo Kalman, UPS, DNS, Temp. Kelvin, Pressao, CO2, Umidade, O2_Raw, O2_Kalman, "
            "Temp.Ambiente, Umidade do AR, P.Atm\n")


def gera_grafico(dados_linha: str):
    if dados_linha is not None and dados_linha != "" and dados_linha != "\r\n":
        valores = dados_linha.replace(" ", "").split(",")

        tempo = int(valores[0])
        fluxo_raw = float(valores[1])
        fluxo_kalman = float(valores[2])
        ups = float(valores[3])
        dns = float(valores[4])
        temp_kelvin = float(valores[5])
        pressao = float(valores[6])
        co2 = float(valores[7])
        umidade = float(valores[8])
        o2_raw = float(valores[9])
        o2_kalman = float(valores[10])
        temp_ambiente = float(valores[11])
        umidade_ar = float(valores[12])
        p_atm = float(valores[13])
        plt.figure(figsize=(10, 6))  # Definir o tamanho da figura
        plt.plot(tempo, fluxo_raw, label='Fluxo Raw')
        plt.plot(tempo, fluxo_kalman, label='Fluxo Kalman')
        plt.plot(tempo, ups, label='UPS')
        plt.plot(tempo, dns, label='DNS')
        plt.plot(tempo, temp_kelvin, label='Temp. Kelvin')
        plt.plot(tempo, pressao, label='Pressão')
        plt.plot(tempo, co2, label='CO2')
        plt.plot(tempo, umidade, label='Umidade')
        plt.plot(tempo, o2_raw, label='O2 Raw')
        plt.plot(tempo, o2_kalman, label='O2 Kalman')
        plt.plot(tempo, temp_ambiente, label='Temp. Ambiente')
        plt.plot(tempo, umidade_ar, label='Umidade do AR')
        plt.plot(tempo, p_atm, label='P. Atm.')

        plt.xlabel('Tempo (ms)')
        plt.ylabel('Valores')
        plt.title('Gráfico para monitoração')
        plt.legend()
        plt.ylim(-8, 400)
        with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tmpfile:
            filename = tmpfile.name
            plt.savefig(tmpfile, format='png')

        return filename
