import flet as ft
from time import sleep


class BuscaDispositivo(ft.UserControl):
    def build(self):
        c1 = ft.Container(
            content=ft.ElevatedButton("Buscar dispositivo"),
            bgcolor=ft.colors.YELLOW,
            padding=5,
        )
        return c1

    def botao_click(self, e):
        pb = ft.ProgressBar(width=400)
